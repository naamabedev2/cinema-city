"""Cinema booking application package."""
