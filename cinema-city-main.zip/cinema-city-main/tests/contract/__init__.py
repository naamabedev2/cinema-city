"""Reusable repository contract tests."""
